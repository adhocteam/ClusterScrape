defmodule BarDeadlock do
  FooDeadlock.__info__(:macros)
end

defmodule BarParallel do
end

require FooParallel
IO.puts FooParallel.message

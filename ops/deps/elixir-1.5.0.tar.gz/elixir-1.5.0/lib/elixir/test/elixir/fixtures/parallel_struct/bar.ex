defmodule BarStruct do
  defstruct name: "", foo: %FooStruct{}
end

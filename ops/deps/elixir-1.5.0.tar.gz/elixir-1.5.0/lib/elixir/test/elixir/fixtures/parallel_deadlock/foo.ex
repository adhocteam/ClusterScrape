defmodule FooDeadlock do
  BarDeadlock.__info__(:macros)
end

-module(rebar_dep).

-export ([any_function/0]).

any_function() ->
    ok.

defmodule ATest do
  use ExUnit.Case

  test "f" do
    assert A.f() == :ok
  end
end

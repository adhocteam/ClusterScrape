defmodule B do
  def f, do: A.f()
end

defmodule A do
  def f, do: :ok
end
